My own module
=========


Module Variables
--------------

| Variable        | Type   |          Default            |    Description    |
|-----------------|--------|-----------------------------|-------------------|
|  path           | string |   /home/$USER/test123.txt   |    path to file   |
|  content        | string |         Test-123\n          |  content in file  |


License
-------

MIT

Author Information
------------------

An optional section for the role authors to include contact information, or a website (HTML is not allowed).